# Welcome to your Local LLM! 🚀🤖

Hi there, Developer! 👋👋 This LLM is powered by Llama2

## Useful Links 🔗

- [The Project's GitHub Page](https://github.com/zoltanctoth/local-chatbot-from-scratch)