#!/usr/bin/env bash

chainlit run final.py --watch